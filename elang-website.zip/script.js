function showMessage() {
    alert("Elang terbang tinggi! 🦅");
}
