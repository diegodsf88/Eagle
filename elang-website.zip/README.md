# 🦅 Elang Website

Project website sederhana bertema elang untuk latihan upload ke GitHub.

## Fitur
- HTML, CSS, JavaScript sederhana
- Tema gelap
- Interaksi tombol

## Cara Menjalankan
1. Download atau clone repo ini
2. Buka file index.html di browser

## Author
Dibuat untuk latihan GitHub 🚀
